# Car Racing Game Python
### I have used python3.12 and pygame library to build this project.
### I have simulated physics(positive & negative acceleration and collision)
![greenLine](https://github.com/artinmohajeri/Car-Racing-Game-Python/assets/95845593/8a531e16-5724-4cf6-b36e-fe4ebc9c0a06)
### Press the keys "w", "s" to move forward and backwards. and press the keys "a", "d" to rotate the car.
### The game has 5 levels. each level, the computer's car is faster.


![Screenshot (116)](https://github.com/artinmohajeri/Car-Racing-Game-Python/assets/95845593/042146b2-2e1a-4bce-b6ce-c742a0e308f8)
![Screenshot (117)](https://github.com/artinmohajeri/Car-Racing-Game-Python/assets/95845593/dc0349bf-92f8-4a8d-8afb-b925743045d0)

